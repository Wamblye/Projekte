function loadTherapieplan(array) {
    /* initialize the external events
    -----------------------------------------------------------------*/
    var initialLocaleCode = 'de';
    var containerEl = document.getElementById('external-events-list');
    new FullCalendar.Draggable(containerEl, {
      itemSelector: '.fc-event',
      eventData: function(eventEl) {
        TitelText = eventEl.innerText;
        return {
          title: eventEl.innerText.trim()
        }
      }
    });

    /* initialize the calendar
    -----------------------------------------------------------------*/
    const benutzer = localStorage.getItem("user");
    var Kategorie = "Therapieplan";
    var kalender = "therapieplan";
    var dbEvents = array;

    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: ''
      },
      locale: initialLocaleCode,
      editable: true,
      droppable: true, 
      eventStartEditable: false, // Verschieben der Blöcke im Kalender verbieten
      eventResize: function(event, delta, revertFunc) {
        // Datum Format ändern
        var datStart = moment(event.event.start).format('YYYY-MM-DD');
        var datEnd = moment(event.event.end).format('YYYY-MM-DD');
        if (datEnd == "Invalid date") {
          datEnd = "null"; 
        }
        // Datenbank aktualisieren
        updateDbKalender(event.event.title, datStart, datEnd, benutzer, Kategorie, kalender);
      },
      eventReceive: function(event) {
        // Datum Format ändern
        var datStart = moment(event.event.start).format('YYYY-MM-DD');
        var datEnd = moment(event.event.end).format('YYYY-MM-DD');
        if (datEnd == "Invalid date") {
          datEnd = "null"; 
        }
      // Termin in Datenbank hinzufügen
       addDbKalender(event.event.title, datStart, datEnd, benutzer, Kategorie, kalender);
      },
      eventClick: function(arg) {
        if (confirm('Möchten Sie wirklich diesen Termin löschen?')) {
          // Datum Format ändern
          var datStart = moment(arg.event.start).format('YYYY-MM-DD');
          var datEnd = moment(arg.event.end).format('YYYY-MM-DD');

          if (datEnd == "Invalid date") {
            datEnd = "null"; 
          }
          // Termin aus Datenbank entfernen
          deleteDbKalender(arg.event.title, datStart, datEnd, benutzer, Kategorie, kalender);
          arg.event.remove(); // aus Kalender entfernen
        }
      },
      events: dbEvents    
    });
    calendar.render();

};