function loadKalender(array) {
    var calendarEl = document.getElementById('calendar');
    var initialLocaleCode = 'de';
    var meine = localStorage.getItem("Meine");
    var station = localStorage.getItem("Station");
    // Daten aus Datenbank holen
    var Kategorie = getKalenderKategorie();
    var kalender = "kalender";
    const benutzer = localStorage.getItem("user");
    // if (benutzer == 1) {
    //   Kategorie = "Station";
    // } else {
    //   Kategorie = "Meine";
    // }
    var dbEvents = array;
    
    //console.log(dbEvents);

  
    var calendar = new FullCalendar.Calendar(calendarEl, {
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: ''
      },
      locale: initialLocaleCode,
      selectable: true,
      selectMirror: true,
      select: function(arg) {
        var title = prompt('Event Title:');
        if (title) {
          calendar.addEvent({
            title: title,
            start: arg.start,
            end: arg.end,
            allDay: arg.allDay
          })

        // Datum Format ändern
        var datStart = moment(arg.start).format('YYYY-MM-DD');
        var datEnd = moment(arg.end).format('YYYY-MM-DD');
        
        // Termin in Datenbank speichern
        addDbKalender(title, datStart, datEnd, benutzer, Kategorie, kalender)
        calendar.unselect();

        dbEvents.push({"title":title, "start":datStart, "end":datEnd},);
        anzeigeEvents(dbEvents, meine, station);
        }
      },
      eventClick: function(arg) {
        if (confirm('Möchten Sie wirklich diesen Termin löschen?')) {
          // Datum Format ändern
          var datStart = moment(arg.event.start).format('YYYY-MM-DD');
          var datEnd = moment(arg.event.end).format('YYYY-MM-DD');

          // Termin in Datenbank löschen
          deleteOhneKategorieDbKalender(arg.event.title, datStart, datEnd, benutzer, kalender);
          //Termin aus Kalender entfernen
          arg.event.remove();
          //Termin aus unterer Liste entfernen
          dbEvents = removeItemArray(dbEvents, arg.event.title, datStart, datEnd);
          anzeigeEvents(dbEvents, meine, station);
        }
      },
      editable: true,
      dayMaxEvents: true, // allow "more" link when too many events
      
      events: dbEvents    
    });

    calendar.render();

    anzeigeEvents(dbEvents, meine, station);
}

function removeItemArray(array, title, start, end) {
  for (var item in array) {
    if (title == array[item].title && start == array[item].start && end == array[item].end) {
      array.splice(item, 1);
    }
  }
  return array;
}


