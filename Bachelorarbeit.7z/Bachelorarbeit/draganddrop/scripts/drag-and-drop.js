          $(function () {
            $("#dad-logo").dad();
    
            // Common dad
            $(".dad-example").dad({
              exchangeable: false,
              placeholderTarget: ".item"
            });
    
            // Multiline/dynamic example
            $(".add-child").on("click", function () {
              // Create new element
              var newElement = document.createElement("div");
              newElement.innerHTML = '<div class="item"><span>Hi dad!</span></div>';
    
              $("#dad-multiline").append(newElement);
            });
    
            $(".remove-child").on("click", function () {
              $("#dad-multiline > div:last").remove();
            });
    
            // Dragable example
            $("#dad-draggable").dad({
              draggable: ".draggable",
              placeholderTarget: ".item-draggable"
            });
    
            // Activate and deactivate example
            var togglable = $("#dad-togglable").dad({
              active: false,
              placeholderTarget: ".item"
            });
    
            $("#activate").on("click", function () {
              togglable.activate();
    
              // Button style only
              $(".button").not(this).removeClass("active");
              $(this).addClass("active");
            });
    
            $("#deactivate").on("click", function () {
              togglable.deactivate();
    
              // Button style only
              $(".button").not(this).removeClass("active");
              $(this).addClass("active");
            });
    
            // Dropzone example
            var droppable = $(".dad-droppable").dad({
              placeholderTarget: ".item"
            });
    
            $(".area-1").on("dadDrop", function (e, element) {
              $(element).remove();
            });

            // Page Bewertung aufrufen, wenn Eintrag in unteren Bereich gezogen wurde
            $("#einträge_speichern").on("dadDrop", function (e, element) {
              var name = $(element).attr('name');
              var punkte = $(element).attr('value');
              var id = $(element).attr('data-id');
              var bewertung;
              var kategorie = localStorage.getItem("kategorie");

              if (kategorie == "Befinden") {
                showBewertung();
              } else {
                bewertung = 6;
              }

              var array = addTagebuchEinträge(id, name, punkte, bewertung);
              // Wenn es mehr als 12 Elemente gibt, soll ein Scrollbalken aktiviert werden
              var grid = document.querySelector("#einträge_speichern");
              if (array.length > 12) {
                grid.classList.add("active");
              } else {
                grid.classList.remove("active");
              }
            });

            // Page Bewertung aufrufen, wenn Eintrag in den oberen Bereich gezogen wurde
            $("#einträge_anzeige").on("dadDrop", function (e, element) {
              var kategorie = localStorage.getItem("kategorie");
              var name = $(element).attr('name');
              var id = $(element).attr('data-id');

              removeTagebuchEinträge(id);
              if (kategorie == "Befinden") {
                removeSmileyEintrag(name);
              }
            });

  
          });
